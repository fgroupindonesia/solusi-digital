  <footer class="footer text-center"> 2021-<?= date('Y') ?> © Solusi Digital developed by <a
                    href="https://www.fgroupindonesia.com/">FGroupIndonesia.com</a>
            </footer>